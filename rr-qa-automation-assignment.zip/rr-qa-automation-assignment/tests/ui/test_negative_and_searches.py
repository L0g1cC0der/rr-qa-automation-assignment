
import pytest, time, logging
pytest.importorskip('selenium')
from pages.discover_page_extended import DiscoverPageExtended

def test_search_positive_and_negative(driver, base_url, tmp_path):
    page = DiscoverPageExtended(driver, base_url)
    page.open('/popular')
    positives = ['Playdate', 'Frankenstein', 'One Battle After Another']
    negatives = ['NonExistentMovieXYZ1234', 'no-such-title-abc-123']
    found_pos = []
    for p in positives:
        try:
            page.search(p)
            time.sleep(1)
            titles = page.get_result_titles()
            if any(p.lower() in t.lower() for t in titles):
                found_pos.append(p)
        except Exception:
            continue
    for n in negatives:
        try:
            page.search(n)
            time.sleep(1)
            titles = page.get_result_titles()
            # expect zero or no match
            assert len(titles) == 0 or all(n.lower() not in t.lower() for t in titles)
        except AssertionError:
            raise
        except Exception:
            # if search failed to run that's acceptable but log
            pass
    assert found_pos, f'No positive searches succeeded; results checked for {positives}'
