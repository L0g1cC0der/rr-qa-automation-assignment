
import pytest, time, logging
LOG = logging.getLogger("test_filters")
pytest.importorskip('selenium')

def _first_page_cards(driver):
    try:
        return driver.execute_script("return Array.from(document.querySelectorAll('.card, .movie-card, .grid-item, .result-item')).map(e=>e.innerText).slice(0,50)")
    except Exception:
        return []

def test_category_filter_changes_results(driver, base_url):
    driver.get(base_url)
    time.sleep(1)
    buttons = ['Popular', 'Trend', 'Newest', 'Top rated', 'Trending', 'Top rated']
    clicked = False
    before = _first_page_cards(driver) or []
    LOG.info('Before count: %d', len(before))
    for b in buttons:
        try:
            el = None
            try:
                el = driver.find_element('xpath', f"//button[contains(translate(normalize-space(text()),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '{b.lower()}')] | //a[contains(translate(normalize-space(text()),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '{b.lower()}')] | //div[contains(translate(normalize-space(text()),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '{b.lower()}')]")
            except Exception:
                el = None
            if not el:
                continue
            try:
                el.click()
            except Exception:
                try:
                    driver.execute_script('arguments[0].click();', el)
                except Exception:
                    continue
            time.sleep(1)
            after = _first_page_cards(driver) or []
            if after != before and len(after) > 0:
                LOG.info('Category %s changed results (before=%d, after=%d)', b, len(before), len(after))
                clicked = True
                assert len(after) > 0
                break
        except Exception as e:
            LOG.info('Could not interact with category %s: %s', b, e)
    assert clicked, 'No category button click produced a visible change. Check selectors.'
