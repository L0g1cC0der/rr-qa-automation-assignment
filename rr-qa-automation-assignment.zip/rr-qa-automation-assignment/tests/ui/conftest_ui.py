import os
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

@pytest.fixture(scope='session')
def base_url():
    return os.getenv('BASE_URL', 'https://tmdb-discover.surge.sh')

@pytest.fixture(scope='module')
def driver(request):
    opts = Options()
    if os.getenv('HEADFUL','0') != '1':
        # use new headless mode where available
        try:
            opts.add_argument('--headless=new')
        except Exception:
            opts.add_argument('--headless')
        opts.add_argument('--disable-gpu')
    opts.add_argument('--no-sandbox')
    opts.add_argument('--window-size=1366,1000')
    # try to create driver
    try:
        svc = Service(ChromeDriverManager().install())
        drv = webdriver.Chrome(service=svc, options=opts)
    except Exception as e:
        pytest.skip(f"Could not start Chrome WebDriver: {e}")
    # ensure reports/screenshots dir exists
    root_reports = os.path.join(os.getcwd(), 'reports')
    screenshots = os.path.join(root_reports, 'screenshots')
    os.makedirs(screenshots, exist_ok=True)
    yield drv
    try:
        drv.quit()
    except Exception:
        pass

def pytest_configure(config):
    # ensure report dir exists
    os.makedirs('reports', exist_ok=True)
    os.makedirs(os.path.join('reports', 'screenshots'), exist_ok=True)
