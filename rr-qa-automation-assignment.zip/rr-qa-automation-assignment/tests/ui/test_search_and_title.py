
import pytest, time, logging
LOG = logging.getLogger("test_search_and_title")
pytest.importorskip('selenium')

def test_search_functionality(driver, base_url):
    driver.get(base_url)
    time.sleep(1)
    # try to find a search input and perform search for some terms
    tried = False
    for term in ('batman','matrix','inception'):
        try:
            el = None
            try:
                el = driver.find_element('xpath', "//input[@type='search'] | //input[contains(@placeholder,'Search')] | //input[contains(@aria-label,'Search')] | //input[contains(@name,'search')]")
            except Exception:
                el = None
            if el is None:
                # try clicking a visible SEARCH button to reveal input
                try:
                    btn = driver.find_element('xpath', "//button[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'search')]|//a[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'search')]")
                    btn.click()
                    time.sleep(0.5)
                    el = driver.find_element('xpath', "//input[@type='search'] | //input[contains(@placeholder,'Search')] | //input[contains(@aria-label,'Search')] | //input[contains(@name,'search')]")
                except Exception:
                    el = None
            if el is None:
                LOG.info('Search input not found for term %s', term)
                continue
            el.clear()
            el.send_keys(term)
            el.send_keys('\\n')
            time.sleep(1)
            count = driver.execute_script("return document.querySelectorAll('img').length || 0")
            LOG.info('Search term %s produced %s results', term, count)
            tried = True
            break
        except Exception as e:
            LOG.info('Search attempt failed for %s: %s', term, e)
    assert tried, 'Could not locate or use a search input on the page.'
