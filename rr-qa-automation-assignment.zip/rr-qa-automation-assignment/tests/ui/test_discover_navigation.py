
import pytest, time
pytest.importorskip('selenium')
from pages.discover_page import DiscoverPage

def test_navigation_tabs_and_search(driver, base_url, tmp_path):
    page = DiscoverPage(driver, base_url)
    page.open('/popular')
    tabs = ['Popular', 'Trend', 'Newest', 'Top rated']
    any_click = False
    for t in tabs:
        try:
            page.click_nav_tab(t)
            any_click = True
            driver.save_screenshot(str(tmp_path / f"tab_{t.replace(' ','_')}.png"))
            titles = page.get_result_titles()
            assert isinstance(titles, list)
        except AssertionError as e:
            # log and continue
            continue
    assert any_click, "No navigation tabs could be clicked; check selectors or page structure"
    # test search if possible
    try:
        page.search('Playdate')
        driver.save_screenshot(str(tmp_path / 'search_playdate.png'))
    except AssertionError:
        pytest.skip('Search input not found on the page')
