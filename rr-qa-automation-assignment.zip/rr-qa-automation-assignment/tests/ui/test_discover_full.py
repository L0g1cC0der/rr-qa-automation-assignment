
import pytest, time, logging
LOG = logging.getLogger("ui.discover_full")
pytest.importorskip('selenium')
from pages.discover_page_extended import DiscoverPageExtended

@pytest.mark.ui
def test_navigate_tabs_and_titles(driver, base_url, tmp_path):
    page = DiscoverPageExtended(driver, base_url)
    page.open('/popular')
    tabs = ['Popular','Trend','Newest','Top rated']
    any_found = False
    for t in tabs:
        try:
            page.click_nav_tab(t)
            time.sleep(1)
            titles = page.get_result_titles()
            driver.save_screenshot(str(tmp_path / f"nav_{t.replace(' ','_')}.png"))
            if titles and len(titles) > 0:
                any_found = True
        except AssertionError as e:
            LOG.warning("Tab %s not found or clickable: %s", t, e)
    assert any_found, "None of the navigation tabs returned visible titles; check selectors or site availability"

@pytest.mark.ui
def test_search_multiple_and_negative(driver, base_url, tmp_path):
    page = DiscoverPageExtended(driver, base_url)
    page.open('/popular')
    search_terms = ['Playdate', 'Frankenstein', 'One Battle After Another', 'NonExistentMovieXYZ1234']
    results = {}
    for term in search_terms:
        try:
            page.search(term)
            time.sleep(1)
            titles = page.get_result_titles()
            driver.save_screenshot(str(tmp_path / f"search_{term.replace(' ','_')}.png"))
            results[term] = titles or []
            if 'NonExistentMovieXYZ1234' in term:
                assert len(results[term]) == 0 or all(term.lower() not in t.lower() for t in results[term])
            else:
                assert any(term.lower() in t.lower() for t in results[term]), f"Expected to find '{term}' in results, found: {results[term]}"
        except AssertionError:
            raise
        except Exception as e:
            # record failure for this term but continue
            LOG.warning("Search for '%s' failed: %s", term, e)
            results[term] = []
    # ensure at least one positive search succeeded
    positives = [t for t in search_terms if t != 'NonExistentMovieXYZ1234' and results.get(t)]
    assert positives, f"No positive search terms returned results. Results: {results}"

@pytest.mark.ui
def test_genre_dropdown_and_clickability(driver, base_url, tmp_path):
    page = DiscoverPageExtended(driver, base_url)
    page.open('/popular')
    genres = page.list_all_genres()
    driver.save_screenshot(str(tmp_path / "genres_list.png"))
    # if no genres found, that's acceptable; otherwise try selecting up to first 3
    if genres:
        for g in genres[:3]:
            ok = page.select_genre(g)
            time.sleep(1)
            driver.save_screenshot(str(tmp_path / f"genre_{g.replace(' ','_')}.png"))
            assert ok, f"Could not select genre: {g}"

@pytest.mark.ui
def test_type_dropdown_and_ratings_and_scroll(driver, base_url, tmp_path):
    page = DiscoverPageExtended(driver, base_url)
    page.open('/popular')
    types_to_try = ['Movie','TV Shows','TV Show','TV']
    any_ok = False
    for t in types_to_try:
        try:
            ok = page.select_type(t)
            driver.save_screenshot(str(tmp_path / f"type_{t.replace(' ','_')}.png"))
            if ok:
                any_ok = True
                time.sleep(1)
        except Exception as e:
            continue
    assert any_ok, "Could not select any type option from the control. Checked variations: Movie/TV Shows."
    ok_star = page.click_rating_star(3)
    driver.save_screenshot(str(tmp_path / "stars_clicked.png"))
    assert ok_star, 'Clicking rating stars failed or not available'
    page.scroll_to_bottom()
    time.sleep(1)
    driver.save_screenshot(str(tmp_path / "scrolled_bottom.png"))
