
import pytest, time, logging
pytest.importorskip('selenium')
from pages.discover_page_extended import DiscoverPageExtended

LOG = logging.getLogger("test_pagination")

def test_pagination_behavior(driver, base_url, tmp_path):
    page = DiscoverPageExtended(driver, base_url)
    page.open('/popular')
    # attempt to scroll and load more content (infinite scroll behavior)
    initial = page.get_result_titles() or []
    # perform some scrolls to try to load more
    for _ in range(4):
        page.scroll_to_bottom()
        time.sleep(1)
    after = page.get_result_titles() or []
    assert isinstance(after, list)
    # either more items loaded or stable list present
    assert len(after) >= 0

def test_year_boundary_filter(driver, base_url, tmp_path):
    page = DiscoverPageExtended(driver, base_url)
    page.open('/popular')
    # set year to extreme boundaries via JS if controls are not accessible
    try:
        # attempt to find year inputs by selectors
        js_set = """(function(){let y1 = document.querySelector("input[placeholder='From']") || document.querySelector("select[name='year_from']"); let y2 = document.querySelector("input[placeholder='To']") || document.querySelector("select[name='year_to']"); if(y1) y1.value='1900'; if(y2) y2.value='2024'; return true; })();"""
        driver = page.driver
        driver.execute_script(js_set)
    except Exception:
        pass
    # scroll and ensure site still responds
    page.scroll_to_bottom()
    time.sleep(1)
    titles = page.get_result_titles()
    assert isinstance(titles, list)

def test_rating_boundary(driver, base_url, tmp_path):
    page = DiscoverPageExtended(driver, base_url)
    page.open('/popular')
    # try clicking the max star and min star
    ok_max = page.click_rating_star(5)
    time.sleep(1)
    ok_min = page.click_rating_star(1)
    assert ok_max or ok_min
