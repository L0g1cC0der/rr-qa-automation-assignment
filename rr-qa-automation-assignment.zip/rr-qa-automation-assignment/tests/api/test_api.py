
import time, logging, requests, pytest
LOG = logging.getLogger("test_api")
@pytest.mark.api
def test_image_urls_reachable(driver, base_url):
    # Use Selenium to collect image URLs from the page, then `requests.head` them.
    driver.get(base_url)
    time.sleep(1)
    js = "return Array.from(document.querySelectorAll('img')).map(i=>i.src).filter(Boolean).slice(0,50);"
    try:
        urls = driver.execute_script(js)
    except Exception:
        urls = []
    if urls is None:
        urls = []
    LOG.info('Collected %d image URLs from the page', len(urls))
    # Be resilient: allow zero images but assert that if images present, they are reachable
    for u in urls:
        try:
            r = requests.head(u, timeout=5, allow_redirects=True)
            assert r.status_code < 400, f'Image URL returned status {r.status_code}: {u}'
        except Exception as e:
            pytest.fail(f'Error while requesting image {u}: {e}')
