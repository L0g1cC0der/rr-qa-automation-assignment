
import time
import logging
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

LOG = logging.getLogger("safe_actions")


def scroll_into_view(driver, el):
    try:
        driver.execute_script("arguments[0].scrollIntoView({block:'center', inline:'center', behavior:'auto'});", el)
    except Exception:
        try:
            driver.execute_script("arguments[0].scrollIntoView();", el)
        except Exception:
            pass


def wait_for_page_ready(driver, timeout=10):
    try:
        WebDriverWait(driver, timeout).until(lambda d: d.execute_script("return document.readyState") in ("complete", "interactive"))
    except Exception:
        pass


def safe_click(driver, el, timeout=8, retries=2, scroll=True, use_action_chain=True):
    """Attempt robust click. Returns True on success, False otherwise."""
    last_exc = None
    for attempt in range(max(1, retries)):
        try:
            if scroll:
                try:
                    scroll_into_view(driver, el)
                except Exception:
                    pass
            if use_action_chain:
                try:
                    ActionChains(driver).move_to_element(el).pause(0.05).click(el).perform()
                    return True
                except Exception as e:
                    last_exc = e
            try:
                el.click()
                return True
            except Exception as e:
                last_exc = e
            try:
                driver.execute_script("arguments[0].click();", el)
                return True
            except Exception as e:
                last_exc = e
        except Exception as e:
            last_exc = e
        time.sleep(0.2)
    LOG.debug("safe_click failed: %s", last_exc)
    return False


def find_clickable_by_text(driver, text, timeout=3):
    xp = f"//*[translate(normalize-space(text()), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = '{text.lower()}']"
    try:
        el = WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((By.XPATH, xp)))
        return el
    except Exception:
        return None
