
#!/usr/bin/env bash
set -euo pipefail
# Optional: export HEADLESS=1 to run headless
HEADLESS="${HEADLESS:-0}"
if [ "$HEADLESS" != "1" ]; then
  echo "Running tests with visible browser. To run headless, set HEADLESS=1"
fi
pytest -q --html=reports/all_report.html --self-contained-html
