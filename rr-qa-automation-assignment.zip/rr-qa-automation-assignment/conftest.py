
import os
import pytest
import logging
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

LOG = logging.getLogger("conftest")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s - %(message)s")


@pytest.fixture(scope="session")
def base_url():
    # override with BASE_URL env if needed
    return os.getenv("BASE_URL", "https://tmdb-discover.surge.sh")


@pytest.fixture(scope="module")
def driver(request):
    """Create a Chrome driver, with safe timeouts and guaranteed cleanup."""
    opts = Options()
    headless = os.getenv("HEADLESS", "0") == "1"
    if headless:
        try:
            opts.add_argument("--headless=new")
        except Exception:
            opts.add_argument("--headless")
        opts.add_argument("--disable-gpu")

    # window size for visible runs
    opts.add_argument("--window-size=1400,1000")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    # Use eager page load so driver returns once DOMInteractive is available in most pages
    try:
        opts.page_load_strategy = "eager"
    except Exception:
        # older selenium might not support this property; ignore if not available
        pass

    try:
        service = Service(ChromeDriverManager().install())
        drv = webdriver.Chrome(service=service, options=opts)
    except Exception as e:
        pytest.skip(f"Could not start Chrome WebDriver: {e}")

    # Short implicit wait; prefer explicit waits in code
    drv.implicitly_wait(2)
    # Prevent forever waits on page load / scripts
    try:
        drv.set_page_load_timeout(30)
    except Exception:
        pass
    try:
        drv.set_script_timeout(30)
    except Exception:
        pass

    yield drv

    # Teardown: always try to quit browser (avoid leaving orphans)
    try:
        drv.quit()
    except Exception:
        try:
            drv.close()
        except Exception:
            pass


def pytest_configure(config):
    os.makedirs("reports/screenshots", exist_ok=True)


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """On test failure, save a screenshot if driver is present."""
    outcome = yield
    rep = outcome.get_result()
    if rep.when == "call" and rep.failed:
        driver = item.funcargs.get("driver")
        if driver:
            try:
                name = item.nodeid.replace("::", "_").replace("/", "_").replace("\\", "_")
                path = os.path.join("reports", "screenshots", f"{name}.png")
                driver.save_screenshot(path)
                LOG.info("Saved failure screenshot: %s", path)
            except Exception as e:
                LOG.warning("Could not save screenshot: %s", e)
