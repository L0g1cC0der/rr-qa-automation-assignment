# Sample Issues Found (examples)

1. ISSUE-001: Direct slug `/popular` returns blank page on refresh
   - Steps: Open https://tmdb-discover.surge.sh/popular and refresh
   - Observed: Page body blank. No fallback to root.
   - Severity: Medium
   - Attachment: screenshot_popular_blank.png

2. ISSUE-002: Pagination to last pages leads to empty results
   - Steps: Navigate to page 15 using page controls
   - Observed: Empty result set with no error message
   - Severity: Low/Medium

3. ISSUE-003: Several poster image URLs return 404
   - Steps: Collected poster URLs via DOM and performed HEAD requests
   - Observed: ~3 images returned 404s
   - Severity: Low
