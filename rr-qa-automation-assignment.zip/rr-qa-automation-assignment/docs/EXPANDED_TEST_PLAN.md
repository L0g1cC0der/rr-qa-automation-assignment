# Expanded Test Plan
Updated: 2025-11-18T06:36:21.598595Z

This file expands the earlier test cases with additional checks for Genre, Year, Rating filters and negative tests for slugs and pagination boundaries.

## New/Updated test cases
- `test_genre_filter_updates_results` — Best-effort interactions with genre widget; asserts posters exist after selection.
- `test_year_and_rating_filters` — Attempts to set year=2020 and rating>=7; asserts page remains healthy and items are present.
- `test_direct_slug_refresh_graceful` — Loads `/popular` directly and asserts non-empty body (detects known demo bug).
- `test_high_page_number_fallback` — Loads `?page=9999` and expects graceful handling.

## Rationale
- The demo app may have dynamic DOM or custom widgets; tests are written to be resilient and prioritize detecting crashes or blank pages rather than strict content matching.

## How to run the expanded suite
- `pytest tests/ui -q --html=reports/ui_report.html --self-contained-html`

