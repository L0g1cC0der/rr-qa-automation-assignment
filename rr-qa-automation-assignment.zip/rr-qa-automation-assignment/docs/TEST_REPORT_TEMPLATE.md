# Test Report - TEMPLATE

## Summary
- Execution date: <date>
- Environment: <local / CI>
- Tests run: <n>
- Failures: <n>

## Defects found
- defect-1: Description
- defect-2: Description

## Artifacts
- HTML reports: reports/ui_report.html, reports/api_report.html
- Logs: logs/<timestamp>.log
