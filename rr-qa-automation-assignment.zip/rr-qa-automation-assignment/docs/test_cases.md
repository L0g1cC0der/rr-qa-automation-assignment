# Test Cases & Strategy

## Testing Strategy
- **Goal:** Validate core filtering and pagination features of the demo TMDB Discover app (https://tmdb-discover.surge.sh/).
- **Types of tests:**
  - **UI tests (Selenium + pytest):** Simulate user interactions and assert DOM / navigation changes.
  - **API / network checks (requests + Selenium JS inspection):** Validate that images and referenced resources are reachable and that the frontend produced data arrays.
- **Test design techniques used:** Equivalence partitioning (valid/invalid filters), boundary value (pagination first vs last pages), exploratory tests for known demo issues (slug refresh & final pages pagination).

## Step-by-step Test Descriptions (examples)

1. **Category filter - Popular / Trending / Newest / Top Rated - Positive**
   - Navigate to the app root.
   - Click on the `Popular` category button.
   - Assert page URL contains `/popular` or the DOM shows "Popular" as the active category.
   - Assert cards are visible and count > 0.

2. **Category filter - Negative / Edge**
   - Manually open the `/popular` slug in a fresh browser window (i.e. use the direct URL) and refresh.
   - Expectation (based on known demo issues): either the page loads or the app gracefully falls back to the root. Test will assert that app still responds without unhandled exceptions (no blank page body).

3. **Type filter - Movies / TV Shows**
   - Apply `Movies` filter and assert that items labeled as movies are present. If the UI does not show type directly, assert that filtering changes results count.

4. **Year & Rating filter**
   - Set a year (e.g., 2020) and rating (>= 5).
   - Assert the visible cards' metadata (if available) match the filters or that results changed.

5. **Genre filter**
   - Open the genre dropdown and select a genre (e.g., Action).
   - Assert cards are updated.

6. **Pagination - Positive**
   - Click to go to page 2 and assert URL or visible active page shows `2` and that result set is different from page 1.

7. **Pagination - Negative / Boundary**
   - Attempt to navigate to a very large page number (e.g., by setting `?page=9999`) and validate app handles it gracefully (error message or fallback).

8. **Resources reachability (API-like checks)**
   - Collect poster image URLs from the first page and call HTTP HEAD on each using `requests` to ensure they return 200/3xx.

## Defect categories to look for
- Broken image links
- Filters that don't affect the result set
- Pagination links that lead to blank pages
- JS runtime errors that crash rendering; tests should detect missing DOM

## CI Integration (high level)
- Use GitHub Actions:
  - A job to run `pytest -q --maxfail=1 --html=reports/ui_report.html` in headless Chrome.
  - Store `reports/` as artifacts.
  - Optionally run UI tests on a self-hosted runner or use a service (e.g., GitHub Actions with `ubuntu-latest` + XVFB or Playwright's infrastructure).
- See `ci/github-actions.yml` for an example template.
