
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
class DiscoverPage:
    def __init__(self, driver, base_url, timeout=8):
        self.driver = driver
        self.base_url = base_url.rstrip('/')
        self.wait = WebDriverWait(driver, timeout)
    def open(self, path='/popular'):
        self.driver.get(self.base_url+path)
        try:
            self.wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR,'.card, .movie-card, .grid-item')))
        except Exception:
            pass
        return self
    def _tab_element(self, name):
        xpaths = [
            f"//a[normalize-space()='{name}']",
            f"//button[normalize-space()='{name}']",
            f"//*[contains(translate(normalize-space(text()),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '{name.lower()}')]"
        ]
        for xp in xpaths:
            try:
                el = self.driver.find_element(By.XPATH, xp)
                if el.is_displayed():
                    return el
            except Exception:
                continue
        return None
    def click_nav_tab(self, name):
        el = self._tab_element(name)
        if el is None:
            raise AssertionError(f"Could not find navigation tab: {name}")
        try:
            el.click()
        except Exception:
            try:
                self.driver.execute_script('arguments[0].click();', el)
            except Exception as e:
                raise AssertionError(f"Click failed: {e}")
        try:
            self.wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR,'.card, .movie-card, .grid-item')))
        except Exception:
            pass
    def search(self, text):
        # try to find search input; if not, raise
        selectors = ["input[type='search']","input[placeholder*='Search']","input[aria-label*='Search']","input[name='search']"] 
        input_el = None
        for sel in selectors:
            try:
                el = self.driver.find_element(By.CSS_SELECTOR, sel)
                if el.is_displayed():
                    input_el = el
                    break
            except Exception:
                continue
        if input_el is None:
            # try reveal by clicking a search icon
            try:
                btn = self.driver.find_element(By.XPATH, "//button[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'search')]|//a[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'search')]" )
                btn.click()
                for sel in selectors:
                    try:
                        input_el = self.wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, sel)))
                        break
                    except Exception:
                        input_el = None
            except Exception:
                input_el = None
        if input_el is None:
            raise AssertionError('Search input not found')
        try:
            input_el.clear()
            input_el.send_keys(text)
            input_el.submit()
        except Exception:
            try:
                input_el.send_keys('\\n')
            except Exception:
                pass
    def get_result_titles(self):
        titles = []
        try:
            elems = self.driver.find_elements(By.CSS_SELECTOR,'.card .title, .movie-card .title, .grid-item .title, .card h3')
            for e in elems:
                t = (e.text or '').strip()
                if t: titles.append(t)
        except Exception:
            pass
        return titles
