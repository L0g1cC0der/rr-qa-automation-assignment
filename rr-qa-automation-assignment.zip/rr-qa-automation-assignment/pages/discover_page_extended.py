
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from utils.safe_actions import safe_click, wait_for_page_ready
import time
import logging

LOG = logging.getLogger("discover_page")


class DiscoverPageExtended:
    def __init__(self, driver, base_url, timeout=12):
        self.driver = driver
        self.base_url = base_url.rstrip("/")
        self.wait = WebDriverWait(driver, timeout)
        self.timeout = timeout

    def open(self, path="/popular"):
        url = f"{self.base_url}{path}"
        try:
            self.driver.get(url)
        except Exception:
            # if page load fails under 'eager', proceed to wait for DOM
            pass
        wait_for_page_ready(self.driver, timeout=self.timeout)
        # quick presence check
        try:
            self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".discover, .app, main, .container")),)
        except Exception:
            pass
        return self

    def _first_cards_snapshot(self, limit=30):
        try:
            arr = self.driver.execute_script(
                "return Array.from(document.querySelectorAll('.card, .movie-card, .grid-item, .result-item')).map(e=>e.innerText).slice(0, arguments[0])",
                limit,
            )
            return arr or []
        except Exception:
            return []

    def _find_tab_element(self, name):
        xps = [
            f"//a[normalize-space()='{name}']",
            f"//button[normalize-space()='{name}']",
            f"//li[normalize-space()='{name}']",
            f"//*[contains(translate(normalize-space(text()), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '{name.lower()}')]",
        ]
        for xp in xps:
            try:
                els = self.driver.find_elements(By.XPATH, xp)
                for e in els:
                    if e.is_displayed():
                        return e
            except Exception:
                continue
        return None

    def click_nav_tab(self, name):
        el = self._find_tab_element(name)
        if not el:
            raise AssertionError(f"Nav tab '{name}' not found")
        before = self._first_cards_snapshot()
        url_before = self.driver.current_url
        ok = safe_click(self.driver, el, timeout=self.timeout, retries=3)
        if not ok:
            raise AssertionError(f"Failed to click nav tab '{name}'")
        # Wait for either URL change or cards change
        try:
            self.wait.until(lambda d: d.current_url != url_before or self._first_cards_snapshot() != before)
        except TimeoutException:
            # final check: maybe the tab is active but content same; not ideal - treat as failure
            raise AssertionError(f"Click on '{name}' did not cause visible change or navigation")

    def get_result_titles(self):
        selectors = [
            ".card .title",
            ".movie-card .title",
            ".grid-item .title",
            ".card h3",
            ".movie-card h3",
            ".grid-item h3",
            ".title",
            ".result-item .title",
        ]
        titles = []
        for sel in selectors:
            try:
                els = self.driver.find_elements(By.CSS_SELECTOR, sel)
                for e in els:
                    t = (e.text or "").strip()
                    if t:
                        titles.append(t)
                if titles:
                    return titles
            except Exception:
                continue
        # fallback anchors
        try:
            anchors = self.driver.find_elements(By.XPATH, "//a[contains(@href,'/movie') or contains(@href,'/title')]")
            for a in anchors:
                t = (a.text or "").strip()
                if t:
                    titles.append(t)
        except Exception:
            pass
        return titles

    def search(self, term):
        input_selectors = [
            "input[type='search']",
            "input[placeholder*='Search']",
            "input[aria-label*='Search']",
            "input[name='search']",
            "input[type='text']",
        ]
        input_el = None
        for sel in input_selectors:
            try:
                elems = self.driver.find_elements(By.CSS_SELECTOR, sel)
                for e in elems:
                    if e.is_displayed():
                        input_el = e
                        break
                if input_el:
                    break
            except Exception:
                continue

        if input_el is None:
            # reveal search icon/button
            try:
                btns = self.driver.find_elements(By.XPATH, "//button[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'search')]|//a[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'search')]")
                for b in btns:
                    if b.is_displayed():
                        if safe_click(self.driver, b, retries=2):
                            # re-check for input
                            for sel in input_selectors:
                                try:
                                    elems = self.driver.find_elements(By.CSS_SELECTOR, sel)
                                    for e in elems:
                                        if e.is_displayed():
                                            input_el = e
                                            break
                                    if input_el:
                                        break
                                except Exception:
                                    continue
                            if input_el:
                                break
            except Exception:
                pass

        if input_el is None:
            # fallback to /search route
            try:
                self.driver.get(self.base_url + "/search")
            except Exception:
                pass
            # wait for input presence
            try:
                for sel in input_selectors:
                    try:
                        elems = self.wait.until(lambda d: d.find_elements(By.CSS_SELECTOR, sel))
                        for e in elems:
                            if e.is_displayed():
                                input_el = e
                                break
                        if input_el:
                            break
                    except Exception:
                        continue
            except Exception:
                pass

        if input_el is None:
            raise AssertionError("Search input not found")

        try:
            input_el.clear()
        except Exception:
            pass
        try:
            input_el.send_keys(term)
        except Exception:
            # js fallback
            try:
                self.driver.execute_script("arguments[0].value = arguments[1]; arguments[0].dispatchEvent(new Event('input'));", input_el, term)
            except Exception as e:
                raise AssertionError("Failed to enter search term: " + str(e))

        # submit via enter or click search button; capture before state then wait for change
        before = self._first_cards_snapshot()
        url_before = self.driver.current_url
        try:
            input_el.submit()
        except Exception:
            try:
                from selenium.webdriver.common.keys import Keys
                input_el.send_keys(Keys.ENTER)
            except Exception:
                # try clicking a nearby search button
                try:
                    btn = self.driver.find_element(By.XPATH, "//button[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'search') or contains(@aria-label,'search')]")
                    safe_click(self.driver, btn, retries=2)
                except Exception:
                    pass
        # wait for results changed
        try:
            self.wait.until(lambda d: d.current_url != url_before or self._first_cards_snapshot() != before)
        except TimeoutException:
            # allow empty results as long as UI responded (no exception)
            pass

    def list_all_genres(self):
        texts = []
        try:
            sels = self.driver.find_elements(By.CSS_SELECTOR, "select[name='genre'], select#genre, select")
            for sel in sels:
                for o in sel.find_elements(By.TAG_NAME, "option"):
                    t = (o.text or "").strip()
                    if t:
                        texts.append(t)
            if texts:
                return texts
        except Exception:
            pass

        # open custom control
        try:
            controls = self.driver.find_elements(By.XPATH, "//label[contains(text(),'Genre')]/following::div[1]//div[contains(@class,'select') or contains(@class,'dropdown') or contains(@class,'control')] | //div[contains(@class,'discover-options') or contains(@class,'filters') or contains(@class,'sidebar')]//div[contains(@class,'select') or contains(@class,'dropdown')]")
            for c in controls:
                try:
                    if c.is_displayed() and safe_click(self.driver, c, retries=2):
                        break
                except Exception:
                    continue
            opts = self.driver.find_elements(By.XPATH, "//ul//li|//div[contains(@class,'option')]|//select//option")
            for o in opts:
                t = (o.text or "").strip()
                if t:
                    texts.append(t)
        except Exception:
            pass
        return texts

    def select_genre(self, genre_text):
        try:
            sels = self.driver.find_elements(By.CSS_SELECTOR, "select[name='genre'], select#genre, select")
            for s in sels:
                for option in s.find_elements(By.TAG_NAME, "option"):
                    if (option.text or "").strip().lower() == genre_text.strip().lower():
                        safe_click(self.driver, option, retries=2)
                        return True
        except Exception:
            pass
        # custom dropdown path
        try:
            controls = self.driver.find_elements(By.XPATH, "//label[contains(text(),'Genre')]/following::div[1]//div[contains(@class,'select') or contains(@class,'dropdown') or contains(@class,'control')] | //div[contains(@class,'discover-options') or contains(@class,'filters') or contains(@class,'sidebar')]//div[contains(@class,'select') or contains(@class,'dropdown')]")
            for c in controls:
                try:
                    if c.is_displayed() and safe_click(self.driver, c, retries=2):
                        break
                except Exception:
                    continue
            opts = self.driver.find_elements(By.XPATH, "//ul//li|//div[contains(@class,'option')]|//li[contains(@class,'option')]")
            for o in opts:
                try:
                    if (o.text or "").strip().lower() == genre_text.strip().lower():
                        safe_click(self.driver, o, retries=2)
                        return True
                except Exception:
                    continue
        except Exception:
            pass
        return False

    def select_type(self, type_text):
        try:
            sels = self.driver.find_elements(By.CSS_SELECTOR, "select[name='type'], select#type, select")
            for s in sels:
                for option in s.find_elements(By.TAG_NAME, "option"):
                    if (option.text or "").strip().lower() == type_text.strip().lower():
                        safe_click(self.driver, option, retries=2)
                        return True
        except Exception:
            pass
        # custom control fallback
        try:
            controls = self.driver.find_elements(By.XPATH, "//label[contains(text(),'Type')]/following::div[1]//div[contains(@class,'select') or contains(@class,'dropdown') or contains(@class,'control')] | //div[contains(@class,'discover-options') or contains(@class,'filters') or contains(@class,'sidebar')]//div[contains(@class,'select') or contains(@class,'dropdown')]")
            for c in controls:
                try:
                    if c.is_displayed() and safe_click(self.driver, c, retries=2):
                        break
                except Exception:
                    continue
            opts = self.driver.find_elements(By.XPATH, "//ul//li|//div[contains(@class,'option')]|//li[contains(@class,'option')]|//select//option")
            for o in opts:
                try:
                    if (o.text or "").strip().lower() == type_text.strip().lower():
                        safe_click(self.driver, o, retries=2)
                        return True
                except Exception:
                    continue
        except Exception:
            pass
        return False

    def click_rating_star(self, index):
        try:
            els = self.driver.find_elements(By.XPATH, "//label[contains(text(),'Ratings')]/following::div//button|//div[contains(@class,'rating')]//button|//span[contains(@class,'star')]|//*[contains(@class,'star')]")
            if els and len(els) >= index:
                return safe_click(self.driver, els[index - 1], retries=2)
        except Exception:
            pass
        # fallback by position
        try:
            el = self.driver.find_element(By.XPATH, f"(//*[contains(@class,'star') or contains(@class,'stars') or contains(@aria-label,'star')])[{index}]")
            return safe_click(self.driver, el, retries=2)
        except Exception:
            return False

    def scroll_to_bottom(self):
        try:
            self.driver.execute_script("window.scrollTo({top: document.body.scrollHeight, behavior: 'smooth'});")
        except Exception:
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        # short pause to allow lazy-load
        time.sleep(0.45)
