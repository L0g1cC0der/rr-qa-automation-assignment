    #!/usr/bin/env bash
    set -e
    REPO_NAME=rr-qa-automation-assignment
    echo "This script will initialize git, create a GitHub repo using 'gh' (if available), and push the code."
    if ! command -v git >/dev/null 2>&1; then
      echo "ERROR: git is not installed on this machine."
      exit 1
    fi
    git init
    git add .
    git commit -m "Initial commit: RR QA Automation Assignment" || true
    if command -v gh >/dev/null 2>&1; then
      echo "Found GitHub CLI. Creating repo..."
      gh repo create $REPO_NAME --public --source=. --remote=origin --push
    else
      echo "GitHub CLI not found. Please create a repo manually on github.com and run:

  git remote add origin https://github.com/<your-username>/$REPO_NAME.git
  git branch -M main
  git push -u origin main
"
    fi
