
# RR QA Automation Assignment

## Project summary
This repository contains the QA automation assignment for RR. It includes API and UI tests implemented with `pytest`. The framework focuses on maintainability, reproducibility, and clear reporting so reviewers can run and validate the suite easily.

## What this submission includes
- Tests: `tests/api/` and `tests/ui/` (if present)
- Test runner: `run_tests.sh`
- Reports: HTML reports generated to `reports/`
- CI hint: `.github/workflows/ci.yml` (example / optional)
- Dependencies: `requirements.txt`
- Defensive import handling in `conftest.py` to avoid failing imports when optional tools are missing

## Quick start (local)
1. Create and activate a virtual environment:
```bash
python -m venv .venv
source .venv/bin/activate     # Windows: .venv\\Scripts\\activate
pip install --upgrade pip
pip install -r requirements.txt
```
2. Run the full test suite and create an HTML report:
```bash
./run_tests.sh
# or
pytest -q --html=reports/all_report.html --self-contained-html
```
3. Run API-only tests:
```bash
pytest tests/api -q
```
4. Run UI tests (requires Chrome/Chromium + webdriver-manager):
```bash
pytest tests/ui -q --headless
```

**Note:** If `selenium` / `webdriver-manager` are not installed or a browser is unavailable, UI tests are intentionally skipped to avoid `ModuleNotFoundError` and allow API tests to run. See `conftest.py` for skip logic and messaging.

## Heads-Up — required assignment answers

### 1. What is your testing strategy?
**Goal:** Validate core user journeys and high-impact features with a mix of API, UI, and negative tests. Prioritise tests that reflect visible user impact (filters, paging, major flows) and include a small set of negative/edge cases to increase confidence.
**Scope:** smoke (render + core flows), integration (API checks), end-to-end (UI flows), and selected negative tests for known unstable behaviors.

### 2. Which cases did you generate? And why?
**Smoke / High priority:** page load, each filter (popular/trending/top-rated), type toggle (Movie/TV), title/year/rating/genre filters individually and combined, and basic pagination (first 3 pages). These represent the most common user interactions.
**Negative / Exploratory:** refresh on route-slugs (e.g. `/popular`), deep pagination jumps, and invalid filter combinations. These target known or likely failure modes.
**Why:** These tests cover user-visible features and known instability areas—providing maximum signal with minimal test surface.

### 3. Information about the test automation framework (libraries used etc.)
- **Test runner:** `pytest` (with fixtures & parametrization)
- **UI automation:** `selenium` + `webdriver-manager` (headless supported)
- **HTTP/API:** `requests`
- **Reporting:** `pytest-html` (self-contained HTML)
- **Logging:** Python `logging` configured via `conftest.py`
Exact versions: see `requirements.txt`.

### 4. Explanation about how to run tests in your framework
See "Quick start" above for exact commands. Use `pip install -r requirements.txt` to install all dependencies. `run_tests.sh` calls `pytest` and places the generated HTML in `reports/all_report.html`.

### 5. Which test design techniques did you use?
- **Equivalence partitioning** — for value ranges (ratings, years).
- **Boundary value analysis** — for pagination and rating boundaries.
- **State-based testing** — ensure filter state persists or resets appropriately.
- **Negative testing** — invalid slugs, deep page jumps.
- **Parametrization** — re-use tests to cover combinations succinctly using `pytest.mark.parametrize`.

### 6. What patterns did you use while coding?
- **Page Object Model (POM)** for UI selectors and actions (keeps tests readable and easy to maintain).
- **Fixture-driven setup/teardown** to centralize resource management (browser sessions, API client).
- **Utilities and helpers** for assertions, retries, screenshot-on-failure, and reporting attachments.
- **Defensive imports** in `conftest.py` to skip UI tests when optional dependencies are missing.

### 7. Which defects did you find?
Include a short list of defects discovered while testing. Example entries (keep real files in `reports/defects/` if available):
- **Slug refresh broken** — refreshing `/popular` sometimes results in empty content. (Severity: Medium)
- **Pagination partial failure** — deep pages may show duplicate or empty content. (Severity: Medium)
- Screenshots and reproduction steps saved under `reports/defects/` when available.

### 8. Reporting, CI integration and reproducibility
- **Reporting:** `pytest-html` creates `reports/all_report.html` containing test results, captured logs, and embedded screenshots for failures. `run_tests.sh` runs the full suite and archives the report.
- **CI:** In CI, install dependencies via `pip install -r requirements.txt`. For UI tests use a runner with headless Chrome or a separate service such as `selenium/standalone-chrome`. Store the HTML report and screenshots as build artifacts.
- **Reproducibility:** Ensure `requirements.txt` pins versions.

## Project structure (example)
```
.
├─ tests/
│  ├─ api/
│  └─ ui/
├─ pages/                 # Page objects (UI)
├─ reports/               # HTML reports + screenshots
├─ logs/                  # run logs
├─ run_tests.sh
├─ requirements.txt
└─ conftest.py
```

## Known issues & assumptions
- The framework intentionally **does not** install dependencies at runtime. Use `pip install -r requirements.txt` before running tests.
- If Selenium or Chrome is absent, UI tests will be skipped (to ensure API tests can still run).
- Assumed default API base URL: `http://localhost:8000` unless `API_BASE_URL` env var is set.
- Some tests may be marked xfail for flaky behaviour under slow network conditions — see tests for `@pytest.mark.xfail` annotations.
