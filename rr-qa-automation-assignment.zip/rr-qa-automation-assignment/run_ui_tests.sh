#!/usr/bin/env bash
set -euo pipefail
echo "Running UI tests..."
python -m pip install --upgrade pip
# Install ui requirements file if present (not forcing network by default)
if [ -f requirements-ui.txt ]; then
  pip install -r requirements-ui.txt
else
  pip install selenium webdriver-manager pytest-html
fi
mkdir -p reports/screenshots
pytest tests/ui -q --html=reports/ui_report.html --self-contained-html
echo "UI tests finished. Report: reports/ui_report.html"
